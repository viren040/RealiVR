import React from 'react'

const Platform = () => {
  return (
    <div>Platform</div>
  )
}

export default Platform